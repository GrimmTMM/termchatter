# Termchatter
Just a simple terminal-based chatting app made using Pusher.<br>
Installable with:<br>
```
pip install termchatter
```